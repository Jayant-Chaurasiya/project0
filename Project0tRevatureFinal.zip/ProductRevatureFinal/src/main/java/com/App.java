package com;
import java.util.*;
public class App {
	Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("Welcome To My Bank App");
		System.out.println();
	

		MainApp mainApp = new MainApp();
		mainApp.startMainApp();
	}
}
